const {Payment, Booking, Place} = require('../model/model');

module.exports.paymentCreate = (req, res, next) => {
    console.log(req.params.id)
    Booking.findByPk(req.params.id)
    .then(paymentFromDB=>{
        res.render('payment',{
            data:paymentFromDB
        });
    })
}

module.exports.paymentCreatePost = (req, res, next) => {
    Payment.create({
            pick: req.body.pick,
            drop: req.body.drop,
            card_no: req.body.card_no,
            card_name: req.body.card_name,
            card_exp: req.body.card_exp,
            pickDate: req.body.pick_date,
            pickTime: req.body.pick_time,
            cost: req.body.cost
        })
        .then(paymentFromDb => {
            res.redirect("/paymentInvoice");
        })  
}
module.exports.paymentInvoice = (req, res, next) => {
    console.log(req.params.id)
    Payment.findByPk(req.params.id)
    .then(paymentFromDB=>{
        res.render('paymentInvoice',{
            data:paymentFromDB
        });
    })
}