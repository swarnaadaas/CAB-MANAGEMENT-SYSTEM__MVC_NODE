const { Admin, Driver } = require('../model/model');


module.exports.adminLogin = (req, res, next) => {
    res.render('adminLogin');
}

module.exports.adminLoginPost = async (req, res, next) => {
    const { email, password } = req.body;
    const adminFromDb = await Admin.findOne({
        where: { email: email, password: password }
    });

    if (adminFromDb == null) {
        return res.render('adminLogin', { message: 'No admin with this email or password was found.' })
    }

    req.session.adminId = adminFromDb.id;
    res.redirect('/index');
}

module.exports.adminRegister = (req, res, next) => {
    res.render('adminRegister');
}

module.exports.adminRegisterPost = async (req, res, next) => {
    const { name, email, password, phone } = req.body;
    let existingAdmin = await Admin.findOne({
        where: {
            email: email
        }
    });

    if (existingAdmin) {
        return res.render('adminRegister', { message: 'Already registered.' });
    }

    await Admin.create({
        name: name,
        email: email,
        password: password,
        phone: phone
    });

    res.redirect('/adminLogin');
}
