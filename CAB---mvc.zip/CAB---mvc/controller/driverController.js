const { Driver } = require('../model/model');

module.exports.driverLogin = (req, res, next) => {
    res.render('driverLogin');
}

module.exports.driverLoginPost = async (req, res, next) => {
    const { email, password } = req.body;
    const driverFromDb = await Driver.findOne({
        where: { email: email, password: password }
    });

    if (driverFromDb == null) {
        return res.render('driverLogin', { message: 'No driver with this email or password was found.' })
    }

    req.session.driverId = driverFromDb.id;
    res.redirect('/driverHome');
}

module.exports.driverRegister = (req, res, next) => {
    res.render('driverRegister');
}
module.exports.driverHome = (req, res, next) => {
    res.render('driverHome')
}

module.exports.driverRegisterPost = async (req, res, next) => {
    const { name, email, license_no, password, phone } = req.body;
    let existingDriver = await Driver.findOne({
        where: {
            email: email
        }
    });

    if (existingDriver) {
        return res.render('driverRegister', { message: 'Already registered.' });
    }

    await Driver.create({
        name: name,
        email: email,
        license_no: license_no,
        password: password,
        phone: phone
    });

    res.redirect('/driverLogin');
}

