const {Driver} = require('../model/model');

module.exports.driverProfileIndex = (req, res, next) => {
    console.log(req.session)
    Driver.findAll({where:{d_id: req.session.driverId}}).then(driverProfiles => {
        res.render('driverProfile-index', {
            data: driverProfiles,
            identity: req.identity.driver
        });
    })
}

module.exports.driverProfileUpdate = async(req, res, next) => {
    Driver.findByPk(req.params.d_id)
        .then(driverProfileFromDb => {
            res.render('driverProfile-update', {
                data: driverProfileFromDb
            });
        });
}

module.exports.driverProfileUpdatePost = async (req, res, next) => {
    await Driver.update(
        {
            name: req.body.name,
            email: req.body.email,
            license_no: req.body.license_no,
            password: req.body.password,
            phone: req.body.phone,
        },
        {
            where: {d_id: req.params.d_id}
        }
    )
    res.redirect('/driverProfileIndex');
}

module.exports.driverProfileDelete = async (req, res, next) => {
    let d_id = req.params.d_id;
    let driverProfileFromDb = await Driver.findByPk(d_id);
    if (driverProfileFromDb != null) {
        await Driver.destroy({
            where: {
                d_id: d_id
            }
        });
        res.redirect("/driverLogin");
    }
}
