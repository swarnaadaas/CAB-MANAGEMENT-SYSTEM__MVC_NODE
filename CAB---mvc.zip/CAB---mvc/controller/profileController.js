const { Passenger } = require('../model/model');

module.exports.profileIndex = (req, res, next) => {
    Passenger.findAll({ where: { id: req.session.passengerId } }).then(profiles => {
        res.render('profile-index', {
            data: profiles,
            identity: req.identity.passenger
        })
    })
}

module.exports.profileUpdate = async (req, res, next) => {
    Passenger.findByPk(req.params.id)
        .then(profileFromDb => {
            res.render('profile-update', {
                data: profileFromDb
            });
        });
}


module.exports.profileUpdatePost = async (req, res, next) => {
    await Passenger.update(
        {
            name: req.body.name,
            email: req.body.email,
            password: req.body.password,
            phone: req.body.phone,
        },
        {
            where: { id: req.params.id }
        }
    )
    res.redirect('/profileIndex');
}

module.exports.profileDelete = async (req, res, next) => {
    let id = req.params.id;
    let profileFromDb = await Passenger.findByPk(id);
    if (profileFromDb != null) {
        await Passenger.destroy({
            where: {
                id: id
            }
        });
        res.redirect("/login");
    }
}
