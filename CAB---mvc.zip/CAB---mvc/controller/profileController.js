const {Passenger} = require('../model/model');

module.exports.profileIndex = (req, res, next) => {
    console.log(req.session)
    Passenger.findAll({where:{p_id: req.session.passengerId}}).then(profiles => {
        res.render('profile-index', {
            data: profiles,
            identity: req.identity.passenger
        })
    })
}

module.exports.profileUpdate = async(req, res, next) => {
    Passenger.findByPk(req.params.p_id)
        .then(profileFromDb => {
            res.render('profile-update', {
                data: profileFromDb
            });
        });
}


module.exports.profileUpdatePost = async (req, res, next) => {
    await Passenger.update(
        {
            name: req.body.name,
            email: req.body.email,
            password: req.body.password,
            phone: req.body.phone,
        },
        {
            where: {p_id: req.params.p_id}
        }
    )
    res.redirect('/profileIndex');
}

module.exports.profileDelete = async (req, res, next) => {
    let p_id = req.params.p_id;
    let profileFromDb = await Passenger.findByPk(p_id);
    if (profileFromDb != null) {
        await Passenger.destroy({
            where: {
                p_id: p_id
            }
        });
        res.redirect("/login");
    }
}
