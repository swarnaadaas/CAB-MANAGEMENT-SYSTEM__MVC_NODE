const {Driver, Passenger} = require('../model/model');


module.exports.adminDriverProfileIndex = (req, res, next) => {
    console.log(req.session)
    Driver.findAll().then(driverProfiles => {
        res.render('driverProfile-index', {
            data: driverProfiles,
            identity: req.identity.driver
        });
    })
}

module.exports.adminProfileIndex = (req, res, next) => {
    console.log(req.session)
    Passenger.findAll().then(Profiles => {
        res.render('profile-index', {
            data: Profiles,
            identity: req.identity.passenger
        });
    })
}
