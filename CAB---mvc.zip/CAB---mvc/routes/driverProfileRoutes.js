const express = require('express');
const controllers = require('../controller/driverProfileController');

const router = express.Router();

router.get('/driverProfileIndex', controllers.driverProfileIndex);
router.get('/driverProfileUpdate/:id', controllers.driverProfileUpdate);
router.post('/driverProfileUpdate/:id', controllers.driverProfileUpdatePost);
router.get('/driverProfileDelete/:id', controllers.driverProfileDelete);

module.exports = router;
