const express = require('express');
const controllers = require('../controller/bookingController');

const router = express.Router();

router.get('/bookingIndex', controllers.bookingIndex);
router.get('/bookingUpdate/:b_id', controllers.bookingUpdate);
router.post('/bookingUpdate/:b_id', controllers.bookingUpdatePost);
router.get('/bookingDelete/:b_id', controllers.bookingDelete);
router.get('/booking', controllers.bookingCreate);
router.post('/booking', controllers.bookingCreatePost);
router.get('/pBookings', controllers.pBookings);


module.exports = router;