const express = require('express');
const controller = require('../controller/adminController');
const controllers = require('../controller/adminProfilesController');

const router = express.Router();

router.get('/adminLogin', controller.adminLogin);
router.post('/adminLogin', controller.adminLoginPost);
router.get('/adminRegister', controller.adminRegister);
router.post('/adminRegister', controller.adminRegisterPost);
router.get('/adminDriverProfileIndex', controllers.adminDriverProfileIndex);
router.get('/adminProfileIndex', controllers.adminProfileIndex);


module.exports = router;