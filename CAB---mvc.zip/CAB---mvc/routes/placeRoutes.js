const express = require('express');
const controllers = require('../controller/placeController');

const router = express.Router();


router.get('/placeCreate', controllers.placeCreate);
router.post('/placeCreate', controllers.placeCreatePost);
router.get('/placeIndex', controllers.placeIndex);
router.get('/placeDelete/:id', controllers.placeDelete);
router.post('/placeUpdate/:id', controllers.placeUpdatePost);
router.get('/placeUpdate/:id', controllers.placeUpdate);

module.exports = router;