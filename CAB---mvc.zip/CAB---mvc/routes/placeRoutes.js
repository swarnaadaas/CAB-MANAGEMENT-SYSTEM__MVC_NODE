const express = require('express');
const controllers = require('../controller/placeController');

const router = express.Router();


router.get('/placeCreate', controllers.placeCreate);
router.post('/placeCreate', controllers.placeCreatePost);
router.get('/placeIndex', controllers.placeIndex);
router.get('/placeDelete/:place_id', controllers.placeDelete);
router.post('/placeUpdate/:place_id', controllers.placeUpdatePost);
router.get('/placeUpdate/:place_id', controllers.placeUpdate);

module.exports = router;