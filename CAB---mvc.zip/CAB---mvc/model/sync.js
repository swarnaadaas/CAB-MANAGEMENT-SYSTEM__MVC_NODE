const {Cab, Passenger, Booking, Driver, Admin, Place, Payment} = require('../model/model');

Passenger.hasMany(Booking);
Booking.belongsTo(Passenger, {
    foreignKey: {
      name: 'passengerId'
    }}
);

Booking.hasMany(Place);
Place.belongsTo(Booking);

Driver.hasMany(Cab);
Cab.belongsTo(Driver);

Payment.hasMany(Place);
Place.belongsTo(Payment);

// Admin.sync({alter: true});
// Driver.sync({alter: true});
// Passenger.sync({alter: true});
// Booking.sync({alter: true});
// Cab.sync({alter: true});
// Payment.sync({alter: true});
// Place.sync({alter: true});
