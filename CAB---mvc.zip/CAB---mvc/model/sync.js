const { Cab, Passenger, Booking, Driver, Admin, Place, Payment } = require('../model/model');

Admin.sync({ alter: true });
Driver.sync({ alter: true });
Passenger.sync({ alter: true });
Place.sync({ alter: true });
Booking.sync({ alter: true });
Cab.sync({ alter: true });
Payment.sync({ alter: true });
