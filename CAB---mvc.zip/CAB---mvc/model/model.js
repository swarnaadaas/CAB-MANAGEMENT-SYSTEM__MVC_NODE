const sequelize = require('./db');
const {DataTypes} = require('sequelize');

const Admin = sequelize.define('Admin', {
    a_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
});

const Booking = sequelize.define('Booking', {
    b_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pick: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    drop: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    cabType: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    pickDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    pickTime: {
        type: DataTypes.TIME,
        allowNull: false,
    }
});

const Cab = sequelize.define('Cab', {
    c_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    cabNo: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    cabType: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    cabCapacity: {
        type: DataTypes.STRING(50),
        allowNull: false,
    }
});

const Driver = sequelize.define('Driver', {
    d_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    license_no: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
});

const Passenger = sequelize.define('Passenger', {
    p_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
});

const Payment = sequelize.define('Payment', {
    pay_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pick: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    drop: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    card_no: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    card_name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    card_exp: {
        type: DataTypes.DATEONLY,
        allowNull: false
    },
    pickDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    pickTime: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
});

const Place = sequelize.define('Place', {
    place_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pick: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    drop: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});

module.exports.Admin = Admin;
module.exports.Booking = Booking;
module.exports.Cab = Cab;
module.exports.Driver = Driver;
module.exports.Passenger = Passenger;
module.exports.Payment = Payment;
module.exports.Place = Place;